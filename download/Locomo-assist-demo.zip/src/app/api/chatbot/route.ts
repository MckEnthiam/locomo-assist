import { NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

const SYSTEM_PROMPT = `Tu es "Locomo", le chatbot assistant virtuel de Locomo-assist, une application de reeducation physique assistee par IA pour les patients togolais en post-AVC ou post-traumatisme.

Ton role :
- Repondre aux questions sur la reeducation, les exercices, la progression
- Donner des conseils motivants et personnalises
- Expliquer les fonctionnalites de l'application
- Aider avec les problemes techniques courants
- Parler en francais de maniere naturelle et chaleureuse

Regles :
- Reponds en francais
- Sois concis mais informatif (2-4 phrases max sauf si l'utilisateur pose une question complexe)
- Utilise un ton bienveillant, encourageant et professionnel
- Ne donne jamais de diagnostic medical — oriente vers un professionnel si necessaire
- Mentionne les fonctionnalites de Locomo-assist quand c'est pertinent (coach IA, camera, rapports, planning)
- Tu peux faire reference au fait que le projet est developpe pour le Togo et l'Afrique de l'Ouest`;

// In-memory conversation history per session (demo mode)
const conversations = new Map<string, Array<{ role: string; content: string }>>();

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      message: string;
      sessionId?: string;
    };

    if (!body.message || typeof body.message !== "string") {
      return NextResponse.json(
        { error: "Message requis" },
        { status: 400 }
      );
    }

    const sessionId = body.sessionId || "default";
    const userMessage = body.message.trim();

    // Get or create conversation history
    let history = conversations.get(sessionId) || [
      { role: "system", content: SYSTEM_PROMPT },
    ];

    // Limit history to last 10 messages (+ system prompt) to avoid token limits
    if (history.length > 12) {
      history = [history[0], ...history.slice(-10)];
    }

    // Add user message
    history.push({ role: "user", content: userMessage });

    try {
      const zai = await ZAI.create();
      const completion = await zai.chat.completions.create({
        messages: history.map((m) => ({
          role: m.role as "system" | "user" | "assistant",
          content: m.content,
        })),
        max_tokens: 300,
      });

      const reply = completion.choices[0]?.message?.content || "Desole, je n'ai pas pu generer une reponse. Essayez encore.";

      // Store assistant reply in history
      history.push({ role: "assistant", content: reply });
      conversations.set(sessionId, history);

      return NextResponse.json({ reply });
    } catch (aiError) {
      console.error("AI SDK error:", aiError);
      // Return a fallback reply if AI fails
      const fallbackReplies: Record<string, string> = {
        default: "Je suis desole, une erreur temporaire est survenue. Veuillez reessayer. En attendant, je vous encourage a continuer vos exercices regulierement.",
      };
      const reply = fallbackReplies.default;
      history.push({ role: "assistant", content: reply });
      conversations.set(sessionId, history);
      return NextResponse.json({ reply });
    }
  } catch (e) {
    console.error("Chatbot error:", e);
    return NextResponse.json({
      reply: "Une erreur est survenue. Veuillez reessayer.",
    });
  }
}
