"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  MessageCircle,
  X,
  Send,
  Minimize2,
  Sparkles,
  Loader2,
} from "lucide-react";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
}

const QUICK_REPLIES = [
  "Comment ameliorer mon amplitude ?",
  "Quel exercice pour l'epaule ?",
  "Comment lire mes rapports ?",
  "Conseil pour aujourd'hui",
];

const WELCOME_MESSAGE: ChatMessage = {
  id: "welcome",
  role: "assistant",
  content:
    "Bonjour ! Je suis Locomo, votre assistant de reeducation. Comment puis-je vous aider aujourd'hui ? Vous pouvez me poser des questions sur vos exercices, votre progression, ou l'application.",
  timestamp: Date.now(),
};

// Smart local fallback responses when API is unavailable
function getLocalFallback(question: string): string {
  const q = question.toLowerCase();

  if (q.includes("amplitude") || q.includes("ameliorer") || q.includes("progresser")) {
    return "Pour ameliorer votre amplitude, pratiquez vos exercices regulierement (5 fois/semaine), respectez les consignes du coach IA pendant les sessions, et evitez les compensations. L'echauffement avant chaque seance est aussi important. La constance est la cle de la reeducation.";
  }
  if (q.includes("epaule") || q.includes("exercice")) {
    return "Pour l'epaule, voici les exercices recommandes : 1) Flexion avant (3x12), 2) Rotation externe (3x15), 3) Abduction laterale (3x10), 4) Pendule Codman (2x20). Commencez par des mouvements lents et augmentez progressivement l'amplitude.";
  }
  if (q.includes("rapport") || q.includes("bilan")) {
    return "Vos rapports sont accessibles dans l'onglet 'Rapports' du menu. Ils contiennent vos donnees d'amplitude par articulation, les compensations detectees, et le score de forme. Vous pouvez les telecharger en HTML ou les imprimer pour votre kinesitherapeute.";
  }
  if (q.includes("conseil") || q.includes("aujourd'hui") || q.includes("jour")) {
    return "Conseil du jour : commencez votre seance par 5 minutes d'echauffement (mouvements lents de l'epaule). Puis faites vos 3 exercices avec une bonne posture. N'oubliez pas de respirer calmement et de garder le dos droit. Vous pouvez consulter votre Planning pour le programme exact.";
  }
  if (q.includes("hanche") || q.includes("mobilisation")) {
    return "Pour la hanche, les exercices cles sont : mobilisation en flexion (3x12), abduction (3x15), pont fessier (3x12 tenir 5s), et marche sur place (2 min). Allongez-vous sur le cote pour les mouvements de rotation.";
  }
  if (q.includes("douleur") || q.includes("mal")) {
    return "Attention : si vous ressentez une douleur vive pendant un exercice, arretez immediatement. Une legere tension est normale, mais la douleur aigue signale qu'il faut consulter votre kinesitherapeute. Ne forcez jamais un mouvement.";
  }
  if (q.includes("session") || q.includes("live") || q.includes("caméra") || q.includes("camera")) {
    return "Pour lancer une session live, allez dans 'Session live' dans le menu. Activez votre camera pour que l'IA analyse vos mouvements en temps reel. Si vous n'avez pas de camera, vous pouvez utiliser le mode demonstration. Le coach IA vous guidera exercice par exercice.";
  }
  if (q.includes("bonjour") || q.includes("salut") || q.includes("hello")) {
    return "Bonjour ! Ravi de vous accompagner dans votre reeducation aujourd'hui. N'hesitez pas a me poser des questions sur vos exercices ou votre progression.";
  }
  if (q.includes("merci")) {
    return "Avec plaisir ! Continuez vos efforts, chaque seance vous rapproche de votre objectif. Je suis la pour vous aider a chaque etape.";
  }
  if (q.includes("aide") || q.includes("comment") || q.includes("fonctionn")) {
    return "Locomo-assist offre : un tableau de bord avec vos statistiques, un planning hebdomadaire, des sessions live avec coach IA, un suivi de progression sur 4 semaines, et des rapports detailles. Utilisez le menu lateral pour naviguer entre les sections.";
  }

  return "Je suis la pour vous aider avec votre reeducation. Vous pouvez me demander des conseils sur les exercices d'epaule ou de hanche, comment lire vos rapports, ou comment ameliorer votre progression. N'hesitez pas a poser votre question !";
}

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME_MESSAGE]);
  const [input, setInput] = useState("");
  const loadingRef = useRef(false);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const sessionIdRef = useRef(`chat-${Date.now()}`);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen && !isMinimized) {
      setTimeout(() => inputRef.current?.focus(), 300);
    }
  }, [isOpen, isMinimized]);

  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed || loadingRef.current) return;

      loadingRef.current = true;
      setIsLoading(true);

      // Add user message
      const userMsg: ChatMessage = {
        id: `user-${Date.now()}`,
        role: "user",
        content: trimmed,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, userMsg]);
      setInput("");

      let reply = "";

      try {
        // Try API with a 25-second timeout
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 25000);

        const res = await fetch("/api/chatbot", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: trimmed,
            sessionId: sessionIdRef.current,
          }),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          reply = data.reply || getLocalFallback(trimmed);
        } else {
          reply = getLocalFallback(trimmed);
        }
      } catch (err: unknown) {
        // Network error, timeout, or API failure — use local fallback
        const isTimeout = err instanceof Error && err.name === "AbortError";
        if (isTimeout) {
          reply = getLocalFallback(trimmed);
        } else {
          reply = getLocalFallback(trimmed);
        }
      }

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: "assistant",
        content: reply,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, botMsg]);

      loadingRef.current = false;
      setIsLoading(false);
    },
    // No dependencies needed — uses refs for loading state
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  const handleQuickReply = (text: string) => {
    sendMessage(text);
  };

  return (
    <>
      {/* Floating Action Button */}
      <button
        onClick={() => {
          setIsOpen(!isOpen);
          setIsMinimized(false);
        }}
        className={`fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-xl flex items-center justify-center transition-all duration-300 hover:scale-110 ${
          isOpen
            ? "bg-gray-700 hover:bg-gray-800 rotate-0"
            : "bg-primary hover:bg-primary/90 animate-bounce-gentle"
        }`}
        title={isOpen ? "Fermer le chat" : "Ouvrir le chat"}
      >
        {isOpen ? (
          <X className="w-5 h-5 text-white" />
        ) : (
          <div className="relative">
            <MessageCircle className="w-6 h-6 text-white" />
            <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-green-400 animate-pulse" />
          </div>
        )}
      </button>

      {/* Chat Panel */}
      {isOpen && (
        <div
          className={`fixed z-50 transition-all duration-300 ease-out ${
            isMinimized
              ? "bottom-24 right-6 w-80"
              : "bottom-24 right-6 w-96 max-w-[calc(100vw-3rem)]"
          }`}
        >
          <Card className="border-0 shadow-2xl overflow-hidden rounded-2xl">
            {/* Header */}
            <div className="bg-gradient-to-r from-primary to-sidebar p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center shrink-0 overflow-hidden">
                <img
                  src="/logo.png"
                  alt="Locomo"
                  className="w-7 h-7 object-contain"
                />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  Locomo
                  <Sparkles className="w-3 h-3 text-amber-300" />
                </h3>
                <p className="text-[10px] text-white/60">
                  Assistant IA de reeducation
                </p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setIsMinimized(!isMinimized)}
                  className="w-8 h-8 rounded-lg hover:bg-white/10 flex items-center justify-center transition-colors"
                  title={isMinimized ? "Agrandir" : "Reduire"}
                >
                  <Minimize2 className="w-3.5 h-3.5 text-white/70" />
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="w-8 h-8 rounded-lg hover:bg-white/10 flex items-center justify-center transition-colors"
                  title="Fermer"
                >
                  <X className="w-3.5 h-3.5 text-white/70" />
                </button>
              </div>
            </div>

            {/* Messages */}
            {!isMinimized && (
              <>
                <CardContent className="p-0">
                  <div className="h-80 overflow-y-auto p-4 space-y-3">
                    {messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex gap-2.5 ${
                          msg.role === "user" ? "flex-row-reverse" : ""
                        }`}
                      >
                        {/* Avatar */}
                        <div className="shrink-0">
                          {msg.role === "assistant" ? (
                            <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                              <img
                                src="/logo.png"
                                alt="Locomo"
                                className="w-5 h-5 object-contain"
                              />
                            </div>
                          ) : (
                            <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center">
                              <span className="text-[10px] font-bold text-white">
                                Vous
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Message bubble */}
                        <div
                          className={`max-w-[75%] px-3 py-2 rounded-xl text-xs leading-relaxed ${
                            msg.role === "user"
                              ? "bg-primary text-white rounded-tr-sm"
                              : "bg-muted text-foreground rounded-tl-sm"
                          }`}
                        >
                          {msg.content}
                        </div>
                      </div>
                    ))}

                    {/* Typing indicator */}
                    {isLoading && (
                      <div className="flex gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden shrink-0">
                          <img
                            src="/logo.png"
                            alt="Locomo"
                            className="w-5 h-5 object-contain"
                          />
                        </div>
                        <div className="bg-muted px-3 py-2.5 rounded-xl rounded-tl-sm">
                          <div className="flex items-center gap-1.5">
                            <Loader2 className="w-3 h-3 text-primary animate-spin" />
                            <span className="text-[10px] text-muted-foreground">
                              Locomo reflechit...
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                    <div ref={messagesEndRef} />
                  </div>
                </CardContent>

                {/* Quick Replies */}
                {messages.length <= 1 && !isLoading && (
                  <div className="px-4 pb-2 flex flex-wrap gap-1.5">
                    {QUICK_REPLIES.map((text) => (
                      <button
                        key={text}
                        onClick={() => handleQuickReply(text)}
                        className="text-[10px] px-2.5 py-1.5 rounded-full bg-primary/10 text-primary hover:bg-primary/20 transition-colors font-medium"
                      >
                        {text}
                      </button>
                    ))}
                  </div>
                )}

                {/* Input */}
                <div className="border-t border-border p-3">
                  <form onSubmit={handleSubmit} className="flex items-center gap-2">
                    <input
                      ref={inputRef}
                      type="text"
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Posez votre question..."
                      disabled={isLoading}
                      className="flex-1 text-xs px-3 py-2 rounded-xl bg-muted border-0 focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground/50 disabled:opacity-50"
                    />
                    <Button
                      type="submit"
                      disabled={!input.trim() || isLoading}
                      size="sm"
                      className="w-8 h-8 p-0 rounded-xl bg-primary hover:bg-primary/90 shrink-0"
                    >
                      {isLoading ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Send className="w-3.5 h-3.5" />
                      )}
                    </Button>
                  </form>
                </div>
              </>
            )}
          </Card>
        </div>
      )}
    </>
  );
}
