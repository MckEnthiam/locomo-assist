'use client';

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';
import { useEffect, useRef } from 'react';

interface SignalGraphProps {
  data: { time: number; amplitude: number }[];
  color?: string;
  showTarget?: boolean;
  targetValue?: number;
}

function SignalTooltip({ active, payload }: any) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 shadow-lg border border-[#c8ddd2]/30 text-xs">
        <p className="text-[#5a7a6a]">t = {payload[0].payload.time.toFixed(1)}s</p>
        <p className="font-bold text-[#085041]">{payload[0].value.toFixed(1)}°</p>
      </div>
    );
  }
  return null;
}

export default function SignalGraph({
  data,
  color = '#1D9E75',
  showTarget = false,
  targetValue = 100,
}: SignalGraphProps) {
  const chartRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chartRef.current) {
      const container = chartRef.current.parentElement;
      if (container) {
        container.scrollTop = container.scrollHeight;
      }
    }
  }, [data]);

  return (
    <div ref={chartRef} className="w-full h-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#c8ddd220" vertical={false} />
          <XAxis
            dataKey="time"
            tick={{ fontSize: 10, fill: '#5a7a6a' }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(v) => `${v.toFixed(0)}s`}
          />
          <YAxis
            tick={{ fontSize: 10, fill: '#5a7a6a' }}
            axisLine={false}
            tickLine={false}
            domain={[0, 180]}
            tickFormatter={(v) => `${v}°`}
          />
          <Tooltip content={<SignalTooltip />} />
          {showTarget && (
            <Line
              type="monotone"
              dataKey={() => targetValue}
              stroke="#EF9F27"
              strokeDasharray="6 4"
              strokeWidth={1}
              dot={false}
              name="Cible"
            />
          )}
          <Line
            type="monotone"
            dataKey="amplitude"
            stroke={color}
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
            name="Amplitude"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
