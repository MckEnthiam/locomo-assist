'use client';

import { motion } from 'framer-motion';
import { IconType } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  suffix?: string;
  icon: IconType;
  color: 'green' | 'amber' | 'blue' | 'rose';
  delay?: number;
}

const colorMap = {
  green: { bg: 'bg-[#E1F5EE]', icon: 'bg-[#1D9E75]', text: 'text-[#085041]' },
  amber: { bg: 'bg-[#FEF3C7]', icon: 'bg-[#EF9F27]', text: 'text-[#92400E]' },
  blue: { bg: 'bg-[#DBEAFE]', icon: 'bg-[#4A90D9]', text: 'text-[#1E40AF]' },
  rose: { bg: 'bg-[#FFE4E6]', icon: 'bg-[#E24B4A]', text: 'text-[#9F1239]' },
};

export default function StatCard({ title, value, suffix, icon: Icon, color, delay = 0 }: StatCardProps) {
  const colors = colorMap[color];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5 }}
      className="bg-white rounded-2xl p-5 shadow-sm border border-[#c8ddd2]/50 hover:shadow-md transition-shadow"
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-[#5a7a6a] font-medium">{title}</p>
          <p className="text-2xl font-bold mt-1 text-[#1a2e23]">
            {value}
            {suffix && <span className="text-sm font-normal text-[#5a7a6a] ml-1">{suffix}</span>}
          </p>
        </div>
        <div className={`w-11 h-11 rounded-xl ${colors.icon} flex items-center justify-center shadow-lg`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
      </div>
    </motion.div>
  );
}
