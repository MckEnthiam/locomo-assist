'use client';

import { motion } from 'framer-motion';
import { Progress } from '@/components/ui/progress';
import { Target } from 'lucide-react';

interface AngleData {
  shoulderLeft: number;
  shoulderRight: number;
  elbowLeft: number;
  spine: number;
  hip: number;
}

interface AnglePanelProps {
  currentAngles: AngleData;
  targetAngles: AngleData;
}

const jointLabels: Record<string, string> = {
  shoulderLeft: 'Épaule G',
  shoulderRight: 'Épaule D',
  elbowLeft: 'Coude G',
  spine: 'Colonne',
  hip: 'Hanche',
};

export default function AnglePanel({ currentAngles, targetAngles }: AnglePanelProps) {
  const joints = Object.keys(jointLabels) as (keyof AngleData)[];

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-4">
        <Target className="w-4 h-4 text-[#1D9E75]" />
        <h4 className="text-sm font-semibold text-[#1a2e23]">Angles articulaires</h4>
      </div>
      {joints.map((joint, i) => {
        const current = currentAngles[joint] || 0;
        const target = targetAngles[joint] || 0;
        const ratio = Math.min((current / target) * 100, 100);
        const isGood = ratio >= 85;
        const isWarn = ratio >= 60 && ratio < 85;

        return (
          <motion.div
            key={joint}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="space-y-1.5"
          >
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#5a7a6a] font-medium">{jointLabels[joint]}</span>
              <span className={`font-bold ${isGood ? 'text-[#1D9E75]' : isWarn ? 'text-[#EF9F27]' : 'text-[#E24B4A]'}`}>
                {current.toFixed(0)}° / {target}°
              </span>
            </div>
            <div className="relative">
              <Progress
                value={ratio}
                className={`h-2 ${
                  isGood
                    ? '[&>div]:bg-[#1D9E75]'
                    : isWarn
                      ? '[&>div]:bg-[#EF9F27]'
                      : '[&>div]:bg-[#E24B4A]'
                }`}
              />
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
