"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuthStore } from "@/store/authStore";
import { motion, AnimatePresence } from "framer-motion";
import {
  Mail,
  Lock,
  User,
  Phone,
  Eye,
  EyeOff,
  ArrowRight,
  ArrowLeft,
  Activity,
  Stethoscope,
  Loader2,
} from "lucide-react";

export function LoginPage() {
  const [isRegister, setIsRegister] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const { login } = useAuthStore();

  // Login fields
  const [loginEmail, setLoginEmail] = useState("demo@locomo.com");
  const [loginPassword, setLoginPassword] = useState("demo123");

  // Register fields
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [regCondition, setRegCondition] = useState("");
  const [regRole, setRegRole] = useState("PATIENT");

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: loginEmail, password: loginPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Erreur de connexion");
      } else {
        login(data.token, data.user);
      }
    } catch {
      setError("Erreur de connexion au serveur");
    }
    setLoading(false);
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: regName,
          email: regEmail,
          password: regPassword,
          phone: regPhone || undefined,
          condition: regCondition || undefined,
          role: regRole,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Erreur d'inscription");
      } else {
        login(data.token, data.user);
      }
    } catch {
      setError("Erreur de connexion au serveur");
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-primary/5" />
      <div className="absolute top-20 left-20 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />

      <div className="w-full max-w-md relative z-10">
        {/* Logo and header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-primary/10 mb-4">
            <img src="/logo.png" alt="Locomo-assist" className="w-14 h-14 object-contain" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">
            Locomo-assist
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Rééducation physique assistée par IA
          </p>
          <div className="flex items-center justify-center gap-2 mt-3">
            <span className="text-[10px] font-semibold text-primary tracking-wider uppercase bg-primary/10 px-3 py-1 rounded-full">
              TCCHackDefend 2026
            </span>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {isRegister ? (
            <motion.div
              key="register"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="border-0 shadow-xl">
                <CardContent className="p-6">
                  <h2 className="text-lg font-bold mb-1 flex items-center gap-2">
                    <User className="w-5 h-5 text-primary" />
                    Créer un compte
                  </h2>
                  <p className="text-xs text-muted-foreground mb-5">
                    Inscrivez-vous pour commencer votre rééducation
                  </p>

                  {error && (
                    <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs font-medium">
                      {error}
                    </div>
                  )}

                  <form onSubmit={handleRegister} className="space-y-3.5">
                    <div>
                      <Label className="text-xs">Nom complet</Label>
                      <div className="relative mt-1">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          className="pl-9 h-10"
                          placeholder="Kofi Mensah"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs">Email</Label>
                      <div className="relative mt-1">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          type="email"
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          className="pl-9 h-10"
                          placeholder="email@exemple.com"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs">Mot de passe</Label>
                      <div className="relative mt-1">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          type={showPassword ? "text" : "password"}
                          value={regPassword}
                          onChange={(e) => setRegPassword(e.target.value)}
                          className="pl-9 pr-9 h-10"
                          placeholder="Min. 6 caractères"
                          minLength={6}
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs">Téléphone (optionnel)</Label>
                      <div className="relative mt-1">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          value={regPhone}
                          onChange={(e) => setRegPhone(e.target.value)}
                          className="pl-9 h-10"
                          placeholder="+228 90 12 34 56"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs">Condition médicale (optionnel)</Label>
                      <div className="relative mt-1">
                        <Stethoscope className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                        <textarea
                          value={regCondition}
                          onChange={(e) => setRegCondition(e.target.value)}
                          className="flex w-full pl-9 rounded-lg border border-input bg-background px-3 py-2 text-sm min-h-[60px] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                          placeholder="AVC, traumatisme, chirurgie..."
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs">Role</Label>
                      <div className="flex gap-2 mt-1">
                        <button
                          type="button"
                          onClick={() => setRegRole("PATIENT")}
                          className={`flex-1 flex items-center justify-center gap-2 p-2.5 rounded-lg border text-xs font-medium transition-all ${
                            regRole === "PATIENT"
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border hover:bg-muted"
                          }`}
                        >
                          <Activity className="w-3.5 h-3.5" /> Patient
                        </button>
                        <button
                          type="button"
                          onClick={() => setRegRole("THERAPIST")}
                          className={`flex-1 flex items-center justify-center gap-2 p-2.5 rounded-lg border text-xs font-medium transition-all ${
                            regRole === "THERAPIST"
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border hover:bg-muted"
                          }`}
                        >
                          <Stethoscope className="w-3.5 h-3.5" /> Thérapeute
                        </button>
                      </div>
                    </div>
                    <Button
                      type="submit"
                      disabled={loading}
                      className="w-full h-10 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/25"
                    >
                      {loading ? (
                        <span className="flex items-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Inscription...
                        </span>
                      ) : (
                        <>
                          Créer mon compte
                          <ArrowRight className="w-4 h-4 ml-1" />
                        </>
                      )}
                    </Button>
                  </form>
                  <button
                    onClick={() => {
                      setIsRegister(false);
                      setError("");
                    }}
                    className="w-full mt-4 text-xs text-muted-foreground hover:text-foreground flex items-center justify-center gap-1 transition-colors"
                  >
                    <ArrowLeft className="w-3 h-3" />
                    Déja un compte ? Se connecter
                  </button>
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <motion.div
              key="login"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="border-0 shadow-xl">
                <CardContent className="p-6">
                  <h2 className="text-lg font-bold mb-1 flex items-center gap-2">
                    <Lock className="w-5 h-5 text-primary" />
                    Connexion
                  </h2>
                  <p className="text-xs text-muted-foreground mb-5">
                    Accedez a votre espace de rééducation
                  </p>

                  {error && (
                    <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs font-medium">
                      {error}
                    </div>
                  )}

                  <form onSubmit={handleLogin} className="space-y-3.5">
                    <div>
                      <Label className="text-xs">Email</Label>
                      <div className="relative mt-1">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          type="email"
                          value={loginEmail}
                          onChange={(e) => setLoginEmail(e.target.value)}
                          className="pl-9 h-10"
                          placeholder="email@exemple.com"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs">Mot de passe</Label>
                      <div className="relative mt-1">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          type={showPassword ? "text" : "password"}
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          className="pl-9 pr-9 h-10"
                          placeholder="Votre mot de passe"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                    <Button
                      type="submit"
                      disabled={loading}
                      className="w-full h-10 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/25"
                    >
                      {loading ? (
                        <span className="flex items-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Connexion...
                        </span>
                      ) : (
                        <>
                          Se connecter
                          <ArrowRight className="w-4 h-4 ml-1" />
                        </>
                      )}
                    </Button>
                  </form>

                  <div className="mt-4 p-3 rounded-lg bg-primary/5 border border-primary/10">
                    <p className="text-[10px] text-muted-foreground">
                      <span className="font-semibold text-primary">Compte de démonstration :</span>
                      <br />
                      demo@locomo.com / demo123
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      setIsRegister(true);
                      setError("");
                    }}
                    className="w-full mt-4 text-xs text-muted-foreground hover:text-foreground flex items-center justify-center gap-1 transition-colors"
                  >
                    Pas encore de compte ? S&apos;inscrire
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
