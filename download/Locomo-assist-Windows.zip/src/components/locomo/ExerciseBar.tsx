'use client';

import { motion } from 'framer-motion';
import { CheckCircle2, Circle, Loader2 } from 'lucide-react';

interface ExerciseBarProps {
  exercises: {
    name: string;
    status: 'pending' | 'active' | 'completed';
    sets: number;
    reps: number;
    currentSet?: number;
    currentRep?: number;
  }[];
  currentIndex: number;
  onSelect: (index: number) => void;
}

export default function ExerciseBar({ exercises, currentIndex, onSelect }: ExerciseBarProps) {
  return (
    <div className="flex items-center gap-2 overflow-x-auto pb-2">
      {exercises.map((exercise, i) => (
        <motion.button
          key={i}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onSelect(i)}
          className={`flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
            i === currentIndex
              ? 'bg-[#1D9E75] text-white shadow-lg shadow-[#1D9E75]/30'
              : exercise.status === 'completed'
                ? 'bg-[#E1F5EE] text-[#085041]'
                : 'bg-white text-[#5a7a6a] border border-[#c8ddd2]'
          }`}
        >
          {exercise.status === 'completed' ? (
            <CheckCircle2 className="w-4 h-4 text-[#1D9E75]" />
          ) : i === currentIndex ? (
            <Loader2 className="w-4 h-4 text-white animate-spin" />
          ) : (
            <Circle className="w-4 h-4 text-[#c8ddd2]" />
          )}
          <span className="whitespace-nowrap">{exercise.name}</span>
        </motion.button>
      ))}
    </div>
  );
}
