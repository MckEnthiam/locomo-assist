'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { Bot } from 'lucide-react';

interface CoachMessage {
  time: number;
  message: string;
}

interface CoachPanelProps {
  messages: CoachMessage[];
  isLive?: boolean;
}

export default function CoachPanel({ messages, isLive = false }: CoachPanelProps) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-4">
        <Bot className="w-4 h-4 text-[#1D9E75]" />
        <h4 className="text-sm font-semibold text-[#1a2e23]">Coach IA</h4>
        {isLive && (
          <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#E1F5EE]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#1D9E75] loco-pulse" />
            <span className="text-[10px] text-[#085041] font-medium">En direct</span>
          </span>
        )}
      </div>
      <div className="space-y-2 max-h-48 overflow-y-auto loco-scrollbar pr-1">
        <AnimatePresence mode="popLayout">
          {messages.map((msg, i) => (
            <motion.div
              key={`msg-${i}`}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="flex gap-2"
            >
              <div className="flex-shrink-0 w-7 h-7 rounded-full bg-[#E1F5EE] flex items-center justify-center mt-0.5">
                <Bot className="w-3.5 h-3.5 text-[#1D9E75]" />
              </div>
              <div className="flex-1 bg-[#E1F5EE] rounded-xl rounded-tl-sm px-3 py-2">
                <p className="text-xs text-[#085041] leading-relaxed">{msg.message}</p>
                <p className="text-[10px] text-[#5a7a6a] mt-1">
                  {Math.floor(msg.time / 60)}:{String(msg.time % 60).padStart(2, '0')}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {messages.length === 0 && (
          <div className="text-center py-6 text-xs text-[#5a7a6a]">
            Le coach vous guidera pendant l&apos;exercice
          </div>
        )}
      </div>
    </div>
  );
}
