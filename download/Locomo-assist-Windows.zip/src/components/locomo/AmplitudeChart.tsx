'use client';

import { motion } from 'framer-motion';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface AmplitudeChartProps {
  data: { date: string; avgAmplitude: number }[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white rounded-xl px-4 py-3 shadow-lg border border-[#c8ddd2]/50">
        <p className="text-xs text-[#5a7a6a]">{label}</p>
        <p className="text-sm font-bold text-[#085041]">
          {payload[0].value}° amplitude
        </p>
      </div>
    );
  }
  return null;
};

export default function AmplitudeChart({ data }: AmplitudeChartProps) {
  if (!data || data.length === 0) return null;

  // Map day names in French
  const dayNames = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];

  const chartData = data.map((d) => {
    const date = new Date(d.date);
    const dayName = dayNames[date.getDay()];
    return { ...d, dayName };
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3, duration: 0.5 }}
      className="bg-white rounded-2xl p-6 shadow-sm border border-[#c8ddd2]/50"
    >
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold text-[#1a2e23]">Amplitude moyenne</h3>
          <p className="text-xs text-[#5a7a6a]">7 derniers jours</p>
        </div>
        <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-[#E1F5EE]">
          <div className="w-2 h-2 rounded-full bg-[#1D9E75]" />
          <span className="text-xs text-[#085041]">Amplitude</span>
        </div>
      </div>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} barCategoryGap="20%">
            <CartesianGrid strokeDasharray="3 3" stroke="#c8ddd240" vertical={false} />
            <XAxis
              dataKey="dayName"
              tick={{ fontSize: 12, fill: '#5a7a6a' }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 12, fill: '#5a7a6a' }}
              axisLine={false}
              tickLine={false}
              domain={[0, 100]}
              tickFormatter={(v) => `${v}°`}
            />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: '#E1F5EE50' }} />
            <Bar dataKey="avgAmplitude" radius={[6, 6, 0, 0]} maxBarSize={40}>
              {chartData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.avgAmplitude > 90 ? '#1D9E75' : entry.avgAmplitude > 75 ? '#4A90D9' : '#EF9F27'}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}
