"use client";

import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { Sidebar } from "@/components/locomo/Sidebar";
import { Dashboard } from "@/components/locomo/Dashboard";
import { Planning } from "@/components/locomo/Planning";
import { SessionLive } from "@/components/locomo/SessionLive";
import { Progression } from "@/components/locomo/Progression";
import { Rapports } from "@/components/locomo/Rapports";
import { Profil } from "@/components/locomo/Profil";
import { Apropos } from "@/components/locomo/Apropos";
import { Parametres } from "@/components/locomo/Parametres";
import { useSessionStore } from "@/store/sessionStore";

export default function Home() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [dashboardData, setDashboardData] = useState<Record<string, unknown> | null>(null);
  const [dashboardLoading, setDashboardLoading] = useState(true);

  const isLive = useSessionStore((s) => s.isLive);

  // Initialize dark mode preference
  useEffect(() => {
    if (typeof window !== "undefined") {
      const darkPref = localStorage.getItem("locomo-dark");
      if (darkPref === "true") {
        document.documentElement.classList.add("dark");
      }
    }
  }, []);

  // Default fallback data so dashboard always shows content
  const FALLBACK_DATA: Record<string, unknown> = {
    totalSessions: 5,
    avgAmplitudeByJoint: { epaule: 96, coude: 0, hanche: 0, colonne: 0 },
    totalDurationSeconds: 6000,
    formScore: 35,
    amplitudeLast7Days: [],
    todayExercises: [
      { id: "ex-1", name: "Mobilisation hanche", sets: 3, reps: 12, bodyPart: "hanche" },
    ],
    dayType: "Hanche — mobilisation",
  };

  // Load dashboard data
  useEffect(() => {
    async function loadDashboard() {
      setDashboardLoading(true);
      try {
        const res = await fetch("/api/sessions?scope=dashboard");
        if (res.ok) {
          setDashboardData(await res.json());
        } else {
          setDashboardData(FALLBACK_DATA);
        }
      } catch {
        setDashboardData(FALLBACK_DATA);
      }
      setDashboardLoading(false);
    }
    void loadDashboard();
  }, [activeTab, isLive]);

  // Refresh dashboard when session ends
  useEffect(() => {
    if (!isLive && activeTab === "dashboard") {
      async function loadDashboard() {
        try {
          const res = await fetch("/api/sessions?scope=dashboard");
          if (res.ok) {
            setDashboardData(await res.json());
          }
        } catch { /* silent */ }
      }
      void loadDashboard();
    }
  }, [isLive, activeTab]);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setSidebarOpen(false);
  };

  const handleStartSession = () => {
    setActiveTab("session");
    setSidebarOpen(false);
  };

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return (
          <Dashboard
            dashboardData={dashboardData}
            onStartSession={handleStartSession}
            loading={dashboardLoading}
          />
        );
      case "planning":
        return <Planning onStartSession={handleStartSession} />;
      case "session":
        return <SessionLive isLive={isLive} onToggleLive={() => {}} />;
      case "progression":
        return <Progression />;
      case "rapports":
        return <Rapports />;
      case "profil":
        return <Profil />;
      case "parametres":
        return <Parametres />;
      case "apropos":
        return <Apropos />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Desktop Sidebar */}
      <div className="hidden md:block md:sticky md:top-0 md:h-screen">
        <Sidebar activeTab={activeTab} onTabChange={handleTabChange} />
      </div>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-30 md:hidden"
            onClick={() => setSidebarOpen(false)}
          />
          <div className="fixed left-0 top-0 z-40 md:hidden">
            <Sidebar activeTab={activeTab} onTabChange={handleTabChange} />
          </div>
        </>
      )}

      {/* Main Content */}
      <main className="flex-1">
        {/* Mobile Header */}
        <header className="md:hidden sticky top-0 z-20 bg-background/80 backdrop-blur-md border-b border-border px-4 py-3">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="w-10 h-10 rounded-xl bg-card border border-border flex items-center justify-center hover:bg-muted transition-colors"
            >
              {sidebarOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
            <div className="flex items-center gap-2">
              <img
                src="/logo.png"
                alt="Locomo-assist"
                className="w-7 h-7 rounded-lg object-contain"
              />
              <span className="font-bold text-primary-dark text-sm">
                Locomo-assist
              </span>
            </div>
            <div className="w-10" />
          </div>
        </header>

        {/* Page Content */}
        <div className="p-4 md:p-6 lg:p-8">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}
