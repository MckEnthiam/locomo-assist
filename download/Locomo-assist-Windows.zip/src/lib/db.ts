import { PrismaClient } from '@prisma/client'
import { join } from 'path'

// Ensure db directory exists
const dbDir = join(process.cwd(), 'db')
try {
  const fs = require('fs')
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true })
  }
} catch {}

// Build DATABASE_URL if not set
if (!process.env.DATABASE_URL) {
  process.env.DATABASE_URL = 'file:' + join(dbDir, 'custom.db')
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

let _db: PrismaClient | undefined
let _initError: Error | undefined

function getDb(): PrismaClient {
  if (_db) return _db
  if (_initError) throw _initError
  
  try {
    _db = new PrismaClient({
      log: ['error'],
    })
    return _db
  } catch (e) {
    _initError = e instanceof Error ? e : new Error(String(e))
    throw _initError
  }
}

export const db = new Proxy({} as PrismaClient, {
  get(_target, prop, receiver) {
    if (prop === 'then' || prop === Symbol.toPrimitive) return undefined
    try {
      const client = getDb()
      const value = Reflect.get(client, prop, receiver)
      if (typeof value === 'function') {
        return value.bind(client)
      }
      return value
    } catch (e) {
      console.error('[db] Error accessing', String(prop), e)
      throw e
    }
  },
})
