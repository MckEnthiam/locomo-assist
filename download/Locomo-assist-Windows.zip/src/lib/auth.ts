import crypto from "crypto";

const SALT = "locomo-assist-hackathon-2026";

export function hashPassword(password: string): string {
  return crypto.scryptSync(password, SALT, 64).toString("hex");
}

export function verifyPassword(password: string, hash: string): boolean {
  const inputHash = crypto.scryptSync(password, SALT, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(inputHash), Buffer.from(hash));
}

export function createToken(user: {
  id: string;
  email: string;
  name: string;
  role: string;
}): string {
  const payload = JSON.stringify({
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
  });
  return Buffer.from(payload).toString("base64url");
}

export function verifyToken(token: string): {
  id: string;
  email: string;
  name: string;
  role: string;
  exp: number;
} | null {
  try {
    const payload = JSON.parse(Buffer.from(token, "base64url").toString());
    if (payload.exp && payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}
