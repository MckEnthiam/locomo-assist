"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { computeJointAngles, detectCompensations, type JointAngles } from "@/lib/poseAngles";

/* eslint-disable @typescript-eslint/no-explicit-any */

interface PoseDetectionState {
  isReady: boolean;
  isLoading: boolean;
  error: string | null;
  angles: JointAngles;
  compensations: { lumbar: boolean; shoulder: boolean };
  landmarks: any[] | null;
  cameraActive: boolean;
}

interface UsePoseDetectionOptions {
  onAnglesUpdate?: (angles: JointAngles, compensations: { lumbar: boolean; shoulder: boolean }) => void;
  enabled?: boolean;
  cameraFacingMode?: "user" | "environment";
}

/** Dynamically load MediaPipe scripts from CDN */
function loadScript(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) {
      resolve();
      return;
    }
    const script = document.createElement("script");
    script.src = src;
    script.crossOrigin = "anonymous";
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`Failed to load ${src}`));
    document.head.appendChild(script);
  });
}

let mediapipeLoaded = false;

async function loadMediaPipe() {
  if (mediapipeLoaded) return;
  await loadScript("https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js");
  await loadScript("https://cdn.jsdelivr.net/npm/@mediapipe/drawing_utils/drawing_utils.js");
  await loadScript("https://cdn.jsdelivr.net/npm/@mediapipe/pose/pose.js");
  mediapipeLoaded = true;
}

export function usePoseDetection({
  onAnglesUpdate,
  enabled = true,
  cameraFacingMode = "user",
}: UsePoseDetectionOptions = {}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const poseRef = useRef<any>(null);
  const cameraRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [state, setState] = useState<PoseDetectionState>({
    isReady: false,
    isLoading: false,
    error: null,
    angles: {
      shoulderLeft: 0,
      shoulderRight: 0,
      elbowLeft: 0,
      elbowRight: 0,
      spine: 0,
      hip: 0,
    },
    compensations: { lumbar: false, shoulder: false },
    landmarks: null,
    cameraActive: false,
  });

  const lastUpdateRef = useRef(0);
  const onAnglesUpdateRef = useRef(onAnglesUpdate);
  onAnglesUpdateRef.current = onAnglesUpdate;

  const onResults = useCallback(
    (results: any) => {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const ctx = canvas?.getContext("2d");

      // Draw video + skeleton on canvas
      if (ctx && video && results.poseLandmarks) {
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 480;
        ctx.save();
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        // Draw skeleton connections
        const connections = [
          [11, 13], [13, 15], // left arm
          [12, 14], [14, 16], // right arm
          [11, 12],           // shoulders
          [11, 23], [12, 24], // torso sides
          [23, 24],           // hips
          [23, 25], [25, 27], // left leg
          [24, 26], [26, 28], // right leg
        ];

        ctx.strokeStyle = "#1D9E75";
        ctx.lineWidth = 3;
        for (const [a, b] of connections) {
          const la = results.poseLandmarks[a];
          const lb = results.poseLandmarks[b];
          if (la && lb && la.visibility > 0.5 && lb.visibility > 0.5) {
            ctx.beginPath();
            ctx.moveTo(la.x * canvas.width, la.y * canvas.height);
            ctx.lineTo(lb.x * canvas.width, lb.y * canvas.height);
            ctx.stroke();
          }
        }

        // Draw landmarks
        for (const lm of results.poseLandmarks) {
          if (lm.visibility > 0.5) {
            ctx.beginPath();
            ctx.arc(lm.x * canvas.width, lm.y * canvas.height, 5, 0, 2 * Math.PI);
            ctx.fillStyle = "#085041";
            ctx.fill();
            ctx.strokeStyle = "#1D9E75";
            ctx.lineWidth = 2;
            ctx.stroke();
          }
        }

        ctx.restore();
      }

      // Calculate joint angles
      if (results.poseLandmarks) {
        const now = Date.now();
        if (now - lastUpdateRef.current < 200) return;
        lastUpdateRef.current = now;

        const landmarks3D = results.poseLandmarks.map((lm: any) => ({
          x: lm.x,
          y: lm.y,
          z: lm.z,
          visibility: lm.visibility,
        }));

        const angles = computeJointAngles(landmarks3D);
        const comps = detectCompensations(angles, {});

        setState((prev) => ({
          ...prev,
          angles,
          compensations: comps,
          landmarks: results.poseLandmarks,
        }));

        onAnglesUpdateRef.current?.(angles, comps);
      }
    },
    []
  );

  const startCamera = useCallback(async () => {
    if (!videoRef.current) return;
    setState((prev) => ({ ...prev, isLoading: true, error: null }));

    try {
      // Load MediaPipe dynamically
      await loadMediaPipe();

      // Access camera
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: cameraFacingMode,
        },
      });
      streamRef.current = stream;
      videoRef.current.srcObject = stream;
      await videoRef.current.play();

      // Create Pose instance
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const PoseClass = (window as any).Pose;
      if (!PoseClass) throw new Error("MediaPipe Pose not loaded");

      const pose = new PoseClass({
        locateFile: (file: string) =>
          `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`,
      });

      pose.setOptions({
        modelComplexity: 1,
        smoothLandmarks: true,
        enableSegmentation: false,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5,
      });

      pose.onResults(onResults);
      poseRef.current = pose;

      // Create camera helper
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const CameraClass = (window as any).Camera;
      if (CameraClass) {
        const camera = new CameraClass(videoRef.current, {
          onFrame: async () => {
            if (poseRef.current && videoRef.current) {
              await poseRef.current.send({ image: videoRef.current });
            }
          },
          width: 640,
          height: 480,
        });
        await camera.start();
        cameraRef.current = camera;
      } else {
        // Fallback: manual frame loop
        const processFrame = async () => {
          if (poseRef.current && videoRef.current && streamRef.current.active) {
            await poseRef.current.send({ image: videoRef.current });
            requestAnimationFrame(processFrame);
          }
        };
        processFrame();
      }

      setState((prev) => ({
        ...prev,
        isReady: true,
        isLoading: false,
        cameraActive: true,
      }));
    } catch (err) {
      const message = err instanceof Error ? err.message : "Erreur d'initialisation de la caméra";
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: message,
        cameraActive: false,
      }));
    }
  }, [onResults, cameraFacingMode]);

  const stopCamera = useCallback(() => {
    if (cameraRef.current) {
      cameraRef.current.stop();
      cameraRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    if (poseRef.current) {
      poseRef.current.close();
      poseRef.current = null;
    }

    setState((prev) => ({
      ...prev,
      cameraActive: false,
      isReady: false,
      landmarks: null,
      angles: {
        shoulderLeft: 0,
        shoulderRight: 0,
        elbowLeft: 0,
        elbowRight: 0,
        spine: 0,
        hip: 0,
      },
      compensations: { lumbar: false, shoulder: false },
    }));
  }, []);

  // Auto-start when enabled
  useEffect(() => {
    if (enabled && videoRef.current && !state.cameraActive && !state.isLoading) {
      startCamera();
    }
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled]);

  return {
    ...state,
    videoRef,
    canvasRef,
    startCamera,
    stopCamera,
  };
}
