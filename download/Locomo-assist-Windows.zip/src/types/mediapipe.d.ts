declare module "@mediapipe/pose" {
  export interface PoseOptions {
    modelComplexity?: number;
    smoothLandmarks?: boolean;
    enableSegmentation?: boolean;
    smoothSegmentation?: boolean;
    minDetectionConfidence?: number;
    minTrackingConfidence?: number;
  }

  export interface NormalizedLandmark {
    x: number;
    y: number;
    z: number;
    visibility: number;
  }

  export interface Results {
    poseLandmarks: NormalizedLandmark[];
    poseWorldLandmarks: NormalizedLandmark[];
    segmentationMask?: any;
  }

  export type ResultsListener = (results: Results) => void;

  export class Pose {
    constructor(config?: { locateFile?: (file: string) => string });
    setOptions(options: PoseOptions): void;
    onResults(listener: ResultsListener): void;
    send(inputs: { image: HTMLVideoElement | HTMLImageElement }): Promise<void>;
    close(): void;
  }
}

declare module "@mediapipe/camera_utils" {
  export interface CameraOptions {
    onFrame: () => Promise<void>;
    width?: number;
    height?: number;
    facingMode?: string;
  }

  export class Camera {
    constructor(videoElement: HTMLVideoElement, options: CameraOptions);
    start(): Promise<void>;
    stop(): void;
  }
}

declare module "@mediapipe/drawing_utils" {
  export function drawConnectors(
    ctx: CanvasRenderingContext2D,
    landmarks: any[],
    connections: any[],
    style: any
  ): void;
  export function drawLandmarks(
    ctx: CanvasRenderingContext2D,
    landmarks: any[],
    style: any
  ): void;
}
