"use client";

import { create } from "zustand";

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar: string | null;
  phone?: string | null;
  birthDate?: string | null;
  condition?: string | null;
  createdAt?: string | null;
}

interface AuthState {
  user: AuthUser | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (token: string, user: AuthUser) => void;
  logout: () => void;
  setUser: (user: AuthUser) => void;
  setLoading: (v: boolean) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: true,

  login: (token, user) => {
    if (typeof window !== "undefined") {
      localStorage.setItem("locomo-token", token);
      localStorage.setItem("locomo-user", JSON.stringify(user));
    }
    set({ token, user, isAuthenticated: true, isLoading: false });
  },

  logout: () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("locomo-token");
      localStorage.removeItem("locomo-user");
    }
    set({ token: null, user: null, isAuthenticated: false, isLoading: false });
  },

  setUser: (user) => set({ user }),

  setLoading: (v) => set({ isLoading: v }),
}));

// Initialize from localStorage on client side
export function initAuth() {
  if (typeof window === "undefined") return;
  const token = localStorage.getItem("locomo-token");
  const userStr = localStorage.getItem("locomo-user");
  if (token && userStr) {
    try {
      const user = JSON.parse(userStr);
      useAuthStore.getState().login(token, user);
    } catch {
      useAuthStore.getState().logout();
    }
  } else {
    useAuthStore.getState().setLoading(false);
  }
}

// Get auth headers for API calls
export function getAuthHeaders(): Record<string, string> {
  const token = useAuthStore.getState().token;
  return token ? { Authorization: `Bearer ${token}` } : {};
}
